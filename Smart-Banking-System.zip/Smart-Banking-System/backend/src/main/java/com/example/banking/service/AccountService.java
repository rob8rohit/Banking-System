package com.example.banking.service;

import org.springframework.stereotype.Service;
import java.util.List;
import com.example.banking.model.Account;
import com.example.banking.repository.AccountRepository;

@Service
public class AccountService {

    private final AccountRepository repo;

    public AccountService(AccountRepository repo) {
        this.repo = repo;
    }

    public Account create(Account a) {
        return repo.save(a);
    }

    public List<Account> all() {
        return repo.findAll();
    }
}
