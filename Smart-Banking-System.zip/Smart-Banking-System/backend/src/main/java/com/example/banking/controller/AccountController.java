package com.example.banking.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.banking.model.Account;
import com.example.banking.service.AccountService;

@RestController
@RequestMapping("/api/accounts")
@CrossOrigin
public class AccountController {

    private final AccountService service;

    public AccountController(AccountService service) {
        this.service = service;
    }

    @PostMapping
    public Account create(@RequestBody Account a) {
        return service.create(a);
    }

    @GetMapping
    public List<Account> all() {
        return service.all();
    }
}
